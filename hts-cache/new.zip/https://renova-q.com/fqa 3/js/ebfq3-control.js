document.addEventListener("DOMContentLoaded", () => {
  const ebfq3Items =
    document.querySelectorAll(
      ".ebfq3-item"
    )


  ebfq3Items.forEach(
    item => {

      const question =
        item.querySelector(
          ".ebfq3-question"
        )


      question.addEventListener(
        "click",
        () => {

          item.classList.toggle(
            "ebfq3-open"
          )

        }

      )

    }
  )



  const ebfq3Hash =
    window.location.hash.replace(
      "#",
      ""
    )


  if (
    ebfq3Hash
  ) {

    const ebfq3Target =
      document.querySelector(
        `[data-ebfq3-id="${ebfq3Hash}"]`
      )


    if (
      ebfq3Target
    ) {

      ebfq3Target.classList.add(
        "ebfq3-open"
      )


      window.scrollTo(
        {

          top:
            ebfq3Target.offsetTop
            -
            40,

          behavior:
            "smooth"

        }
      )

    }

  }
})