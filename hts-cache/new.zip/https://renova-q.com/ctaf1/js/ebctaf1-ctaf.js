document.addEventListener("DOMContentLoaded", function () {

    const telLinks = document.querySelectorAll('a[href^="tel:"]');

    const popup = document.getElementById("ctaf1-qr-popup");

    const qrImage = document.getElementById("ctaf1-qr-image");

    const qrNumber = document.getElementById("ctaf1-qr-number");


    function isTouchDevice() {

        return (

            'ontouchstart' in window ||

            navigator.maxTouchPoints > 0 ||

            navigator.msMaxTouchPoints > 0

        );

    }


    telLinks.forEach(link => {

        link.addEventListener("click", function (e) {

            if (!isTouchDevice()) {

                e.preventDefault();

                const rect = this.getBoundingClientRect();

                const phoneNumber = this.getAttribute("href").replace("tel:", "");


                qrImage.src =

                    `https://api.qrserver.com/v1/create-qr-code/?size=200x200&data=tel:${phoneNumber}`;

                qrNumber.textContent = phoneNumber;


                popup.style.left = rect.left + "px";

                popup.style.top = rect.bottom + window.scrollY + "px";


                popup.classList.add("ctaf1-active");

            }

        });

    });


    document.querySelector(".ctaf1-close").onclick = () =>

        popup.classList.remove("ctaf1-active");


    document.addEventListener("click", function(e){

        if(!popup.contains(e.target) &&

           !e.target.closest('a[href^="tel:"]'))

        {

            popup.classList.remove("ctaf1-active");

        }

    });

});



